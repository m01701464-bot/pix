package com.pix.helper

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    val KNOWN_APPS: LinkedHashMap<String, String> = linkedMapOf(
        "org.telegram.messenger" to "Telegram",
        "org.telegram.messenger.web" to "Telegram (с сайта)",
        "org.thunderdog.challegram" to "Telegram X",
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.vkontakte.android" to "ВКонтакте",
        "ru.oneme.app" to "MAX",
        "com.viber.voip" to "Viber",
        "com.discord" to "Discord",
        "com.instagram.android" to "Instagram",
        "com.google.android.apps.messaging" to "Сообщения Google (SMS)",
        "com.samsung.android.messaging" to "Сообщения Samsung (SMS)",
        "com.facebook.orca" to "Messenger",
        "com.Slack" to "Slack"
    )

    private const val OLD_PERSONA =
        "Отвечай дружелюбно и коротко, как живой человек. Скажи, что я сейчас занят и отвечу позже. " +
            "Если вопрос простой и ответ очевиден из переписки — можно ответить по сути. " +
            "Если что-то срочное — пусть напишут слово «срочно»."

    const val DEFAULT_PERSONA =
        "Отвечай дружелюбно, на «ты» с друзьями, по сути вопроса — как ответил бы я сам. " +
            "Если без меня не решить — скажи, что уточню и напишу."

    private val p: SharedPreferences
        get() = App.instance.getSharedPreferences("pix", Context.MODE_PRIVATE)

    private fun s(k: String, d: String): String = p.getString(k, d) ?: d
    private fun put(k: String, v: String) = p.edit().putString(k, v).apply()

    // ---------- Настройки ----------
    var apiKey: String
        get() = s("apiKey", "")
        set(v) = put("apiKey", v)

    var chatModel: String
        get() = s("chatModel", "claude-sonnet-5-5")
        set(v) = put("chatModel", v)

    var replyModel: String
        get() = s("replyModel", "claude-haiku-5-5")
        set(v) = put("replyModel", v)

    var ownerName: String
        get() = s("ownerName", "")
        set(v) = put("ownerName", v)

    var persona: String
        get() = s("persona", DEFAULT_PERSONA).let { if (it == OLD_PERSONA) DEFAULT_PERSONA else it }
        set(v) = put("persona", v)

    var prefix: String
        get() = s("prefix", "🤖")
        set(v) = put("prefix", v)

    var cooldownMin: Int
        get() = p.getInt("cooldown", 10)
        set(v) = p.edit().putInt("cooldown", v).apply()

    /** Отвечать самому, если хозяин молчит silenceMin минут */
    var silenceReply: Boolean
        get() = p.getBoolean("silenceReply", true)
        set(v) = p.edit().putBoolean("silenceReply", v).apply()

    var silenceMin: Int
        get() = p.getInt("silenceMin", 2)
        set(v) = p.edit().putInt("silenceMin", v).apply()

    var replyGroups: Boolean
        get() = p.getBoolean("replyGroups", false)
        set(v) = p.edit().putBoolean("replyGroups", v).apply()

    var notifyUrgent: Boolean
        get() = p.getBoolean("notifyUrgent", true)
        set(v) = p.edit().putBoolean("notifyUrgent", v).apply()

    var apps: Set<String>
        get() = s("apps", KNOWN_APPS.keys.joinToString(","))
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        set(v) = put("apps", v.joinToString(","))

    var overlayEnabled: Boolean
        get() = p.getBoolean("overlayEnabled", false)
        set(v) = p.edit().putBoolean("overlayEnabled", v).apply()

    var overlayX: Int
        get() = p.getInt("ox", -1)
        set(v) = p.edit().putInt("ox", v).apply()

    var overlayY: Int
        get() = p.getInt("oy", -1)
        set(v) = p.edit().putInt("oy", v).apply()

    // ---------- Режим «Я занят» ----------
    var busy: Boolean
        get() = p.getBoolean("busy", false)
        private set(v) = p.edit().putBoolean("busy", v).apply()

    var busyUntil: Long
        get() = p.getLong("busyUntil", 0L)
        private set(v) = p.edit().putLong("busyUntil", v).apply()

    fun isBusy(): Boolean {
        if (!busy) return false
        val u = busyUntil
        if (u > 0 && System.currentTimeMillis() > u) {
            busy = false
            busyUntil = 0
            Bus.emit(Event("busy"))
            return false
        }
        return true
    }

    /** minutes <= 0 — до ручного выключения */
    fun setBusy(on: Boolean, minutes: Int) {
        busy = on
        busyUntil = if (on && minutes > 0) System.currentTimeMillis() + minutes * 60_000L else 0L
        log("busy", if (on) "Режим «Я занят» включён" + (if (minutes > 0) " на $minutes мин" else "") else "Режим «Я занят» выключен")
        Bus.emit(Event("busy"))
    }

    fun busyText(): String {
        if (!isBusy()) return "Ты свободен — Пикс не отвечает за тебя"
        val u = busyUntil
        return if (u > 0) "Ты занят до ${time(u)} — Пикс отвечает за тебя" else "Ты занят — Пикс отвечает за тебя"
    }

    // ---------- JSON-списки ----------
    @Synchronized
    private fun arr(k: String): JSONArray = try {
        JSONArray(s(k, "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    @Synchronized
    private fun saveArr(k: String, a: JSONArray, max: Int) {
        val out = if (a.length() > max) {
            val n = JSONArray()
            for (i in a.length() - max until a.length()) n.put(a.get(i))
            n
        } else a
        put(k, out.toString())
    }

    private fun objs(a: JSONArray): List<JSONObject> {
        val l = ArrayList<JSONObject>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { l.add(it) }
        return l
    }

    // Входящие
    @Synchronized
    fun addInbox(pkg: String, app: String, chat: String, sender: String, text: String, group: Boolean, seen: Boolean) {
        val a = arr("inbox")
        a.put(
            JSONObject().put("t", System.currentTimeMillis()).put("pkg", pkg).put("app", app)
                .put("chat", chat).put("sender", sender).put("text", text)
                .put("group", group).put("seen", seen)
        )
        saveArr("inbox", a, 300)
    }

    @Synchronized
    fun unseenCount(): Int = objs(arr("inbox")).count { !it.optBoolean("seen", true) }

    @Synchronized
    fun takeInbox(limit: Int, onlyUnseen: Boolean, markSeen: Boolean): List<JSONObject> {
        val a = arr("inbox")
        val all = objs(a)
        val picked = all.filter { !onlyUnseen || !it.optBoolean("seen", true) }.takeLast(limit)
        if (markSeen) {
            for (o in all) o.put("seen", true)
            val n = JSONArray()
            all.forEach { n.put(it) }
            saveArr("inbox", n, 300)
        }
        return picked
    }

    @Synchronized
    fun markAllSeen() {
        takeInbox(0, onlyUnseen = true, markSeen = true)
    }

    @Synchronized
    fun chatHistory(pkg: String, chat: String, n: Int): List<JSONObject> =
        objs(arr("inbox")).filter { it.optString("pkg") == pkg && it.optString("chat") == chat }.takeLast(n)

    // Журнал
    @Synchronized
    fun log(type: String, text: String) {
        val a = arr("log")
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("type", type).put("text", text))
        saveArr("log", a, 150)
        Bus.emit(Event("log"))
    }

    @Synchronized
    fun logLines(n: Int): List<String> = objs(arr("log")).takeLast(n).reversed().map {
        val icon = when (it.optString("type")) {
            "reply" -> "💬"
            "skip" -> "⏭"
            "error" -> "⚠️"
            "remind" -> "⏰"
            "busy" -> "🟢"
            "urgent" -> "❗"
            "task" -> "✅"
            else -> "•"
        }
        "${time(it.optLong("t"))}  $icon ${it.optString("text")}"
    }

    // Задачи
    private fun nextId(): Int {
        val id = p.getInt("nextId", 1)
        p.edit().putInt("nextId", id + 1).apply()
        return id
    }

    @Synchronized
    fun addTask(title: String): Int {
        val id = nextId()
        val a = arr("tasks")
        a.put(JSONObject().put("id", id).put("title", title).put("done", false).put("t", System.currentTimeMillis()))
        saveArr("tasks", a, 200)
        log("task", "Новая задача: $title")
        return id
    }

    @Synchronized
    fun tasks(): List<JSONObject> = objs(arr("tasks"))

    @Synchronized
    fun setTaskDone(id: Int, done: Boolean): JSONObject? {
        val l = tasks()
        val t = l.firstOrNull { it.optInt("id") == id } ?: return null
        t.put("done", done)
        val n = JSONArray()
        l.forEach { n.put(it) }
        saveArr("tasks", n, 200)
        return t
    }

    @Synchronized
    fun deleteTask(id: Int): Boolean {
        val l = tasks()
        val keep = l.filter { it.optInt("id") != id }
        if (keep.size == l.size) return false
        val n = JSONArray()
        keep.forEach { n.put(it) }
        saveArr("tasks", n, 200)
        return true
    }

    // Напоминания
    @Synchronized
    fun addReminder(at: Long, text: String): Int {
        val id = nextId()
        val a = arr("reminders")
        a.put(JSONObject().put("id", id).put("at", at).put("text", text))
        saveArr("reminders", a, 100)
        return id
    }

    @Synchronized
    fun reminders(): List<JSONObject> = objs(arr("reminders"))

    @Synchronized
    fun removeReminder(id: Int) {
        val n = JSONArray()
        reminders().filter { it.optInt("id") != id }.forEach { n.put(it) }
        saveArr("reminders", n, 100)
    }

    // Утилиты
    fun time(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
    fun dateTime(t: Long): String = SimpleDateFormat("d MMM, HH:mm", Locale("ru")).format(Date(t))
}
